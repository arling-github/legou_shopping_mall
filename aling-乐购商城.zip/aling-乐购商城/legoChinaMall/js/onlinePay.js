$(function(){
//点击银行卡，如果状态未激活，显示激活状态，如果激活过，取消激活样式
    $(".card").click(changeActive);
    $(".recent").click(changeActive);
    function changeActive(){
        if($(this).hasClass("active")){
            $(this).removeClass("active")
        }else{
            $(this).addClass("active")
        }
    }

//点击添加银行卡，增加银行卡
    $(".addCard").click(function(){
       $(".LegoPayment:first").clone(true).prependTo("#payNow");
    });

//蒙层罩随窗口大小改变而变化，并且底层body内容不能滚动
    $(window).resize(function(){
        if($("section").hasClass("coverBox")){
            let hei = $(this).height()+"px";
            let wid = $(this).width();
            $(".coverBox").css({"width":wid,"height":hei});
            $("body","html").css({"height":"100%","overflow":"hidden"})
        }
    }).trigger("resize");

//关闭蒙层罩，显示完整的body内容
    $(".close,.confirm").click(function(){
        $("body","html").css({"overflow":"auto"});
        $(".coverBox").css({"display":"none"});
    })














});