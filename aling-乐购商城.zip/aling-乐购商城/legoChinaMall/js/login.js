$(function(){

    //登录
    //鼠标移入二维码的时候，显示手机扫码提示图片
    $(".scanToLogin").hover(function(){
        $(".phonePic").stop().show(1000);
    },function(){
        $(".phonePic").stop().hide(1000);
    });
    //鼠标点击登录方式，显示对应的登录选择
    $("#login .tabName span").click(function(){
        //显示当前登录方式的激活样式
        $(this).addClass("active").siblings().removeClass("active");
        //获取索引
        let index = $(this).index();
        //显示对应的登录内容
        $(".loginMethod li").hide().eq(index).show();
    });
    //当输入用户名的时候,显示后面的删除图标;点击删除图标，删除内容，并且隐藏自身
    let user = document.querySelector(".username input");
    let del = document.querySelector("#delete");
    user.oninput = function(){
        if(this.value.length>=1){
            del.style.display = "block";
            //点击删除按钮，删除用户名里的内容
            del.onclick=function(){
                user.value = "";
                del.style.display = "none";
            };
        }else{
            del.style.display = "none";
        }
    };



});