$(function () {

    //主图-轮播的参数配置
    $("#bigFocus").slidebox({
        boxh:410,//盒子的高度
        w:1000,//图片的宽度
        h:370,//图片的高度
        isShow:true,//是否显示控制器
        isShowBtn:true,//是否显示左右按钮
        controltop:10,//控制按钮上下偏移的位置,要将按钮向下移动   首先保证boxh 高度>图片 h
        controlsW:20,//控制按钮宽度
        controlsH:20,//控制按钮高度
        radius:10//控制按钮圆角度数
    });

    //电子书轮播
    $(".ebookBanner").slidebox({
        boxh:220,//盒子的高度
        w:330,//图片的宽度
        h:220,//图片的高度
        isShow:true,//是否显示控制器
        isShowBtn:true,//是否显示左右按钮
        controltop:5,//控制按钮上下偏移的位置,要将按钮向下移动   首先保证boxh 高度>图片 h
        controlsW:20,//控制按钮宽度
        controlsH:4,//控制按钮高度
        radius:4,//控制按钮圆角度数
        controlsColor:"#d8d8d8",//普通控制按钮的颜色
        controlsCurrentColor:"#ff6600"//当前控制按钮的颜色
    });

    //电子书选项卡
    $("#eBook .ebook_left .title1 span").mouseover(function(){
        let index = $(this).index();//获取索引
        $(this).addClass("active").siblings().removeClass("active");//显示当前菜单的激活样式
        $("#eBook .ebook_left .content").hide().eq(index).show();//显示当前的内容卡
    });

    //电子书新书畅销榜
    $(".ebook_right li").mouseenter(function(){
        $(".ebook_right li h4").show();//显示所有标题
        $(".ebook_right li div").hide();//隐藏所有div内容
        $(this).find("h4").hide();//隐藏当前标题
        $(this).find("div").stop().fadeIn(500);//显示当前div内容
    });

    //子菜单轮播
    $(".subBanners").slidebox({
        boxh:342,//盒子的高度
        w:418,//图片的宽度
        h:340,//图片的高度
        isShow:true,//是否显示控制器
        isShowBtn:true,//是否显示左右按钮
        controltop:5,//控制按钮上下偏移的位置,要将按钮向下移动   首先保证boxh 高度>图片 h
        controlsW:20,//控制按钮宽度
        controlsH:4,//控制按钮高度
        radius:2,//控制按钮圆角度数
        controlsColor:"#d8d8d8",//普通控制按钮的颜色
        controlsCurrentColor:"#ff6600"//当前控制按钮的颜色
    });

    //服装选项卡
    $("#clothes .title1 span").mouseover(function(){
        let index = $(this).index();//获取索引
        $(this).addClass("active").siblings().removeClass("active");//显示当前菜单的激活样式
        $("#clothes .contents").hide().eq(index).show();//显示当前的内容卡
    });

    //户外运动选项卡
    $("#sports .title1 span").mouseover(function(){
        let index = $(this).index();//获取索引
        $(this).addClass("active").siblings().removeClass("active");//显示当前菜单的激活样式
        $("#sports .contents").hide().eq(index).show();//显示当前的内容卡
    });

    //童装选项卡
    $("#childCloth .title1 span").mouseover(function(){
        let index = $(this).index();//获取索引
        $(this).addClass("active").siblings().removeClass("active");//显示当前菜单的激活样式
        $("#childCloth .contents").hide().eq(index).show();//显示当前的内容卡
    });

    //推广产品选项卡
    $("#promoGoods .title1 .goodsTabIcon i").mouseover(function(){
        let index = $(this).index();//获取索引
        $(this).addClass("active").siblings().removeClass("active");//显示当前菜单的激活样式
        $("#promoGoods .goodsList").hide().eq(index).fadeIn();//显示当前的内容卡
    });

    //回到顶部
    $("#TopCouFloor .goToTop img,.topIcon").click(function(){
        $("html").animate({"scrollTop":"0"},1000);
    });

    //领券中心定位
    $("#TopCouFloor .coupon>p").hover(function(){
        $("#TopCouFloor .coupon img.barCode").stop().animate({"left":"-100px"},500);
    },function(){
        $("#TopCouFloor .coupon img.barCode").stop().animate({"left":"0"},500);
    });

    // 顶部固定搜索框
    $(document).scroll(function(){
        let scrollTop = $(this).scrollTop();//获取滚动高度
        if(scrollTop>=200){
            $("#topSearch").slideDown(500);//显示顶部搜索栏
            $("header .logoNavSearch form").appendTo("#topSearch .searchBox");//移动搜索框到顶部
        }else if(scrollTop<200){
            $("#topSearch").slideUp(500);
            $("#topSearch .searchBox form").appendTo("header .logoNavSearch .search")
        }

    })
        //领券中心超出隐藏
        .scroll(function(){
        let scrollTop = $(this).scrollTop();//获取滚动高度
        if(scrollTop>=4000){
            $("#TopCouFloor .coupon").slideUp(300);
        }else{
            $("#TopCouFloor .coupon").slideDown(300);
        }

    })
        //楼层滚动显示隐藏
        .scroll(function(){
        let scrollTop = $(this).scrollTop();//获取滚动高度
        if(scrollTop>=750 && scrollTop<3600){
            $("#TopCouFloor .floor").slideDown(300);//显示楼层滚动
        }else if(scrollTop>4000||scrollTop<750){
            $("#TopCouFloor .floor").slideUp(300);//隐藏楼层滚动
        }
    })
        //滚动到指定楼层，该楼层显示激活样式
        .scroll(getActive);
        function getActive(){
            $(".floor li").each(function(){
                let index = $(this).index(); //获取索引
                let color = $(this).attr("data-color");//获取颜色
                let thisTop = $(".floorBox").eq(index).offset().top-100;//获取当前内容top值
                let hei = $(".floorBox").eq(index).height();//获取当前内容高度
                let winTop = $("html").scrollTop();//获取滚动高度
                if(winTop>=thisTop && winTop<=thisTop+hei){
                    $(this).css({"backgroundColor":color,"background-position-x":"-40px"});
                }else{
                    $(this).css({"backgroundColor":"#f2f2f2","background-position-x":"0"});
                }
            })
        }

    //楼层滚动hover效果
    $("#TopCouFloor .floor li").hover(function(){
        let iconColor = $(this).attr("data-color");
        $(this).css({"backgroundColor":iconColor,"width":"80px","background-position-x":"-40px"});
    },function(){
        let index = $(this).index();
        $(this).css({"backgroundColor":"#f2f2f2","width":"40px","background-position-x":"0"});
    })
        //滚动到指定楼层
        .click(function(){
            let index = $(this).index(); //获取索引
            let top = $(".floorBox").eq(index).offset().top-70;//获取高度
            $("html,body").animate({"scrollTop":top},300);
        });





//产品列表-轮播的参数配置
    $("#productBanner").slidebox({
        boxh:410,//盒子的高度
        w:1000,//图片的宽度
        h:370,//图片的高度
        isShow:true,//是否显示控制器
        isShowBtn:true,//是否显示左右按钮
        controltop:10,//控制按钮上下偏移的位置,要将按钮向下移动   首先保证boxh 高度>图片 h
        controlsW:20,//控制按钮宽度
        controlsH:20,//控制按钮高度
        radius:10//控制按钮圆角度数
    });

 //热卖畅销
    $("#menuBanner .hotSale li").mouseenter(function(){
        $("#menuBanner .hotSale li").stop().animate({"height":"40px"},1);
        $(this).stop().animate({"height":"120px"},1)
    });

//新书上架，主编推荐
    $(".newBookRecommend li").mouseenter(function(){
        $(".newBookRecommend li h4").show();//显示所有标题
        $(".newBookRecommend li div").hide();//隐藏所有div内容
        $(this).find("h4").hide();//隐藏当前标题
        $(this).find("div").stop(true).fadeIn(500);//显示当前div内容
    });

//独家提供
    $("#listBanner").slidebox({
        boxh:530,//盒子的高度
        w:1200,//图片的宽度
        h:500,//图片的高度
        isShow:true,//是否显示控制器
        isShowBtn:true,//是否显示左右按钮
        controltop:15,//控制按钮上下偏移的位置,要将按钮向下移动   首先保证boxh 高度>图片 h
        controlsW:12,//控制按钮宽度
        controlsH:12,//控制按钮高度
        radius:10//控制按钮圆角度数
    });

//鼠标移入选项卡，切换banner列表
    $("#provision .provTab li").mouseover(function(){
        let index = $(this).index();//获取索引
        let wid = $("#listBanner .innerwrapper li").width();//获取的宽度
        $("#provision .provTab li").removeClass("active");//移除li的active
        $(this).addClass("active");//添加当前active
        $("#listBanner .innerwrapper").stop(true).animate({"left":-index*wid},1000);
    });

//猜你喜欢
    let num = 0; //点击次数
    let hei = $("#favorite .favoList").height();
    $("#favorite .title img").click(function(){
        num++;
        if(num==$("#favorite .favoList").length){
            num=1;
            $("#favorite .favoBox").css({"top":0})
        }
        $("#favorite .favoBox").stop(true).animate({"top":-num*hei},500)
    });

//放大镜
    var magnifierConfig = {
        magnifier : "#magnifier1",//最外层的大容器
        width : 340,//承载容器宽
        height : 350,//承载容器高
        moveWidth : null,//如果设置了移动盒子的宽度，则不计算缩放比例
        zoom : 5//缩放比例
    };
    var _magnifier = magnifier(magnifierConfig);

//商品种类选择
    $(".kind span").click(function(){
        if( $(this).hasClass("active")){
            $(this).removeClass("active");
        }else {
            $(this).addClass("active").siblings().removeClass("active");//为当前添加active类名
        }
       });
//添加购买商品数量
    $("#plus").click(function(){
        $("#minus").css({"cursor":"pointer"}).prop({"disabled":false});
        let number = $("#bookDetail .amount input").val();
        $("#bookDetail .amount input").val(++number);
    });
//减少购买商品数量
    $("#minus").click(function(){
        let number = $("#bookDetail .amount input").val();
        if(number<=1){
            number=1;
            $(this).css({"cursor":"not-allowed"}).prop({"disabled":true});
        }else{
            $(this).css({"cursor":"pointer"}).prop({"disabled":false});
            $("#bookDetail .amount input").val(--number);
        }
    });
//手动输入购买数量
    $(".amount input").change(function(){
        let val = $(this).val();
        if(val<=1||isNaN(val)){
            $(this).val(1);
        }
    });

//添加到购物车
    $(".addToCar").click(function(){
        let addNum = parseInt($("#bookDetail .amount input").val());//添加的数量
        let existNum = parseInt($(".shopCar span").text());//获取购物车已经有的数量
        $(".shopCar span").text(addNum+existNum);
    });
//切换商品评论和简介
    $(".introComment .title span").click(function(){
        $(this).addClass("active").siblings().removeClass("active");
        let index = $(this).index();
        $("#goodsIntro .introComment>div").hide().eq(index).show();
        console.log(index);
    });



});
