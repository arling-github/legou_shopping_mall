$(function(){

//会员中心---首页轮播的参数配置
    $("#vipBanner").slidebox({
        boxh:474,//盒子的高度
        w:732,//图片的宽度
        h:474,//图片的高度
        isShow:true,//是否显示控制器
        isShowBtn:true,//是否显示左右按钮
        controltop:5,//控制按钮上下偏移的位置,要将按钮向下移动   首先保证boxh 高度>图片 h
        controlsW:12,//控制按钮宽度
        controlsH:12,//控制按钮高度
        radius:10,//控制按钮圆角度数
        controlsColor:"#d8d8d8",//普通控制按钮的颜色
        controlsCurrentColor:"#ff6600"//当前控制按钮的颜色
    });
//会员中心首页--鼠标移入商品，显示添加到购物车
    $(".beanCoupon li").mouseenter(function(){
        $(this).find(".addToCar").stop().slideDown(300);
    }).mouseleave(function(){
        $(this).find(".addToCar").stop().slideUp(300);
    });
//会员中心---我的订单，全选的时候勾选所有订单商品
    $(".checkAll").change(function(){
        let bool = $(this).prop("checked");
        if(bool){
            $(".checkOne").prop({"checked":true});
            $(".checkAll").prop({"checked":true});
        }else{
            $(".checkOne").prop({"checked":false});
            $(".checkAll").prop({"checked":false});
        }
        getPrice();
    });
//取消单个商品，取消全选
    $("table").on("change",".checkOne",function(){
        let flag=true;
        $(".checkOne").each(function(){
            let bool=$(this).prop("checked");
            if(bool===false){
                flag=false;
                return false;
            }
        });
        if(flag){
            $(".checkAll").prop({"checked":true});
        }else{
            $(".checkAll").prop({"checked":false});
        }
        getPrice();
    });
//点击删除，删除当前订单
   $("table").on("click",".del",function(){
       $(this).closest("tr").remove();
       getPrice();
   });
//点击删除选中项，删除勾选的订单
    $("table").on("click",".delSelect",function(){
        $(".checkOne").each(function(){
          let bool = $(this).prop("checked");
          if(bool){
              $(this).closest("tr").remove();
          }
        });
        getPrice();
    });
//计算订单数量、勾选商品数量和勾选商品的价格函数
    function getPrice(){
        let index=0;
        let num=0;
        let totalP = 0;
        $(".checkOne").each(function(){
            index++;
            let bool = $(this).prop("checked");
            if(bool){
                num++;
                let singleP = parseFloat($(this).closest("tr").find(".subCount").text());
                totalP+=singleP;
            }
        });

        totalP=totalP.toFixed(2);
        $(".orderNum").text(index);
        $(".totalNum").text(num);
        $(".totalPrice").text(totalP);
    }

//点击去结算，出现防层罩。蒙层罩随窗口大小改变而变化，并且底层body内容不能滚动
    function showCover(){
        let hei = $(window).height()+"px";
        let wid = $(window).width();
        $(".coverBox").css({"display":"block","width":wid,"height":hei});
        $("body","html").css({"height":"100%","overflow":"hidden"})
    }
    $(".gotoCount").click(function () {
        showCover();
    });

//关闭蒙层罩，显示完整的body内容
    $(".close,.confirm,.cancel").click(function(){
        $("body","html").css({"overflow":"auto"});
        $(".coverBox").css({"display":"none"});
    });
});