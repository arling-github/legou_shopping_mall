$(function(){

    var demo=$(".registerform").Validform({
        tiptype:3,
        label:".label",
        showAllError:true,
        datatype:{
            "zh1-6":/^[\u4E00-\u9FA5\uf900-\ufa2d]{1,6}$/
        },
    });


    demo.tipmsg.w["zh1-6"]="请输入1到6个中文字符！";

    demo.addRule([{
        ele:".inputxt:eq(0)",
        datatype:"zh4-6"
    },
        {
            ele:".inputxt:eq(1)",
            datatype:"*6-12",
            Nullmsg:"请设置密码"
        },
        {
            ele:".inputxt:eq(2)",
            datatype:"*6-12",
            recheck:"userpassword"
        },
        {
            ele:".inputxt:eq(3)",
            datatype:"m",
            Nullmsg:"请填写11位手机号码"
        },
        {
            ele:".inputxt:eq(4)",
            datatype:"*",
            Nullmsg:"请输入验证码"
        },
        {
            ele:".inputxt:eq(5)",
            datatype:"*",
            Nullmsg:"请输入手机验证码"
        }]);



    //生成随机验证码
    function getCode(){
        var arr = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','0','1','2','3','4','5','6','7','8','9'];
        var code = '';
        for(var i = 0 ; i < 4 ; i ++ )
            code += ''+arr[Math.floor(Math.random() * arr.length)];
        return code;
    }
    $(".validateCode").click(function(){
        $(this).text(getCode());
    });

    //多少秒后发送验证码
    $(".phoneValidate i").click(getTime);
	//验证码倒计时提醒函数
    function getTime(){
        $(this).unbind("click");
        let num=60;
        $(".phoneValidate i").text(num+"秒后再发送");
        let timer = setInterval(function(){
            if(num==1){
                clearInterval(timer);
                $(".phoneValidate i").bind("click",getTime);
                $(".phoneValidate i").text("重新发送");
            }else{
                num--;
                $(".phoneValidate i").text(num+"秒后再发送");
            }
        },1000);
    }
});