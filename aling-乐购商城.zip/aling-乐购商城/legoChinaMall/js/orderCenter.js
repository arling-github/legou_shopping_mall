$(function(){
   //点击checkBox，显示激活状态，隐藏兄弟的激活状态；如果当前处于激活状态，怎隐藏激活状态
    $(".checkBox").click(function(){
        if($(this).hasClass("active")){
            $(this).removeClass("active");
        }else{
            $(this).addClass("active").siblings(".checkBox").removeClass("active")
        }
    });
    $(".checkBox1").click(function(){
        if($(this).hasClass("active")){
            $(this).removeClass("active");
        }else{
            $(".checkBox1").removeClass("active");
            $(this).addClass("active")
        }
    });

//点击提交订单，出现防层罩。蒙层罩随窗口大小改变而变化，并且底层body内容不能滚动
    $(".submit").click(function(){
        $(".coverBox").css({"display":"block"});
        $("body","html").css({"height":"100%","overflow":"hidden"});
    });
    $(window).resize(function(){
            let hei = $(window).height()+"px";
            let wid = $(window).width()+"px";
            $(".coverBox").css({"width":wid,"height":hei});

    }).trigger("resize");


//关闭蒙层罩，显示完整的body内容
    $(".close,.confirm,.cancel").click(function(){
        $("body","html").css({"overflow":"auto"});
        $(".coverBox").css({"display":"none"});
    });

//点击添加地址，增加地址框
    $(".addAddress,.add").click(function(){
        $(".newAddress:first").clone(true).appendTo(".recipient").css({"display":"block"})
    });
//点击删除地址。删除当前地址
    $(".del").click(function(){
        $(this).closest(".newAddress").remove();
    });




});