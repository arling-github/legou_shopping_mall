
$(function(){

//购物车
    //需求1：点击全选，勾选所有的商品。取消全选，取消勾选所有的商品
        $(".checkAll").change(function(){
            let bool = $(this).prop("checked");
            if(bool){
                $(".checkOne").prop("checked",true);
                $(".checkAll").prop("checked",true);
            }else{
                $(".checkOne").prop("checked",false);
                $(".checkAll").prop("checked",false);
            }
            getTotalPrice();
        });
    //需求2：判断是否选择了全部商品，如果是，selectAll勾选
        $("table").on("change",".checkOne",function(){
            //建立标杆
            let flag = true;
            //遍历商品是否都勾选
            $(".checkOne").each(function(){
                let bool = $(this).prop("checked");
                //判断标杆的值
                if(bool===false){
                    flag=false;
                    return false;
                }
            });
            //根据标杆判断是否是全选
            if(flag){
                $(".checkAll").prop("checked",true);
            }else{
                $(".checkAll").prop("checked",false);
            }
            getTotalPrice();
        });
    //需求3：添加加号，增加商品数量、价格；点击减号，减少商品数量、价格
        $("table").on("click",".add",function(){
            $(".reduce").css("cursor","pointer");
            //获取当前数量
            let num = $(this).closest("tr").find(".singleNum").val();
            ++num;
            //赋值给商品数量
            $(this).closest("tr").find(".singleNum").val(num);
            //计算价格
            getsubCount(this,num);
            getTotalPrice();
        });
        $("table").on("click",".reduce",function(){
            //获取当前数量
            let num = $(this).closest("tr").find(".singleNum").val();
            //判断
            if(num<=1){
                $(this).closest("tr").find(".singleNum").val(1);
                $(this).css("cursor","not-allowed");
            }else{
                $(this).closest("tr").find(".singleNum").val(--num);
            }
            //计算价格
            getsubCount(this,num);
            getTotalPrice();
        });
    //需求4：手动输入数量，计算价格
        let inputNum = document.querySelectorAll(".singleNum");
        for (let i = 0; i<inputNum.length ; i++) {
            inputNum[i].oninput = function(){
                let val = this.value;
                //判断，如果当前输入的值小于1或者不是数字，则直接输出1
                if(isNaN(val)||val<=1){
                    this.value = "1";
                }
                //获取单价
                let singlePrice = document.querySelectorAll(".singlePrice")[i].innerText;
                //计算价格
                let thePrice = singlePrice*this.value;
                thePrice=thePrice.toFixed(2);
                //输出价格
                document.querySelectorAll(".subCount")[i].innerHTML = thePrice;
                getTotalPrice();
            };
        }
    //小计函数
        function getsubCount(obj,num){
        //获取商品的单价
        let singlePrice = $(obj).closest("tr").find(".singlePrice").text();
        //计算总价
        let subCount = singlePrice*num;
        subCount = subCount.toFixed(2);
        $(obj).closest("tr").find(".subCount").text(subCount);
    }
    //计算商品的总价的函数
        function getTotalPrice(){
            //定义初始的数量、价格
            let totalNum = 0;
            let totalPrice =0;
            //判断商品是否是勾选状态
            $(".checkOne").each(function(){
                let bool = $(this).prop("checked");
                if(bool){
                    //获取每个商品的数量
                    let singleNum = parseInt($(this).closest("tr").find(".singleNum").val());
                    //获取勾选商品的总数量
                    totalNum+=singleNum;
                    //获取商品的小计价格
                    let singlePrice = parseFloat($(this).closest("tr").find(".subCount").text());
                    //获取勾选商品的总价格
                    totalPrice+=singlePrice;
                }
            });
            //输出商品的数量和价格
            $(".totalNum").text(totalNum);
            $(".totalPrice").text(totalPrice.toFixed(2));
        }
    //点击删除，删除当前的商品。
        $("table").on("click",".del",function(){
            $(this).closest("tr").remove();
        });
    //点击删除选中商品，删除勾选的商品
        $(".delSelect").click(function(){
            $(".checkOne").each(function(){
                let bool = $(this).prop("checked");
                if(bool){
                    $(this).closest("tr").remove()
                }
            })
        });













});
